^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pi_sonar
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.0 (2020-05-30)
------------------
* Updating pigpio to v71 (`#11 <https://github.com/UbiquityRobotics/pi_sonar/issues/11>`_)
* Contributors: Jim Vaughan, MoffKalast, Rohan Agrawal

0.4.0 (2019-02-16)
------------------
* fix incorrect launch file in the README
* Basic diagnostics added
* Contributors: Rohan Agrawal, Rohit Suri

0.3.1 (2018-06-04)
------------------
* explictly add rpath
* Contributors: Rohan Agrawal

0.3.0 (2018-06-04)
------------------
* Initial Release
* Contributors: Jim Vaughan Rohan Agrawal
